﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace hm_01
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

       



        private void writeFile (string text)
        {
            string filename = "Staistic.txt";
            using (StreamWriter sw = new StreamWriter(filename,true))
            {
                sw.WriteLine(text);
            }
        }
        private void CountSentence()
        {

            Application.Current.Dispatcher.Invoke(new Action(() => {


               
                 string[] arrText = tbText.Text.Split('.', '!', '?');
                 int count = arrText.Count() - 1;
                 tbTextCountSent.Text = count.ToString();

                 string fileExapm = $"Count Sentence {count}";

                writeFile(fileExapm);

            }));

        }
        private void CountSymbol()
        {
            Application.Current.Dispatcher.Invoke(new Action(() => {
                
                    int countSymbolText = tbText.Text.Length;
                    tbTextCountSymb.Text = countSymbolText.ToString();
                    string fileExamp = $"Count symbol {countSymbolText}";
                writeFile(fileExamp);
            }));
        }

        private void CountWord()
        {
            Application.Current.Dispatcher.Invoke(new Action(() => {

                string[] Word = tbText.Text.Split(' ');
               int countWord = Word.Count();
               tbTextCountWord.Text = countWord.ToString();
                string fileExapm = $"Count Count word {countWord}";

                writeFile(fileExapm);



            }));
        }

        private void CountVopros()
        {
            Application.Current.Dispatcher.Invoke(new Action(() => {

                string[] arrWord = tbText.Text.Split('?');
                int countVopros = arrWord.Count()-1;
                tbTextCountVopros.Text = countVopros.ToString();
                string fileExapm = $"Count Vopros {countVopros}";

                writeFile(fileExapm);
            }));
        }

        private void CountVosklik()
        {
            Application.Current.Dispatcher.Invoke(new Action(() => {

                string[] arrWord = tbText.Text.Split('!');
                int countVoskl = arrWord.Count() - 1;
                tbTextCountVosklik.Text = countVoskl.ToString();
                string fileExapm = $"Count Vosklik {countVoskl}/t";

                writeFile(fileExapm);
            }));
        }

        public MainWindow()
        {
       
            InitializeComponent();
           
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Task task1 = new Task(() => CountSentence());
            task1.Start();
            Task task2 = new Task(() => CountSymbol());
            task2.Start();
            Task task3 = new Task(() => CountWord());
            task3.Start();
            Task task4 = new Task(() => CountVopros());
            task4.Start();
            Task task5 = new Task(() => CountVosklik());
            task5.Start();


            //CountSentence(tbText.Text);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Task taskSymbol = new Task(() => CountSymbol());
            taskSymbol.Start();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Task taskSentence = new Task(() => CountSentence());
            taskSentence.Start();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Task taskWord = new Task(() => CountWord());
            taskWord.Start();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Task taskVopros = new Task(() => CountVopros());
            taskVopros.Start();
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Task taskVosklik = new Task(() => CountVosklik());
            taskVosklik.Start();
        }
    }


    /*Создайте оконное приложение, использующее механизм задач(класс Task). Пользователь вводит в текстовое
поле некоторый текст.По нажатию на кнопку приложение
должно проанализировать текст и вывести отчет.Отчёт
содержит информацию о:
■ Количестве предложений;
■ Количестве символов;
■ Количестве слов;
■ Количестве вопросительных предложений;
■ Количестве восклицательных предложений.
Отчёт в зависимости от выбора пользователя отображается на экране или сохраняется в файл.*/

}
