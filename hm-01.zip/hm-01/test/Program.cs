﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] fileCollection = Directory.GetFiles("C:/Users/Vadim/Desktop/directoria", "*.txt");

            for (int  i = 0;  i <fileCollection.Count();  i++)
            {
               

            }

        }
    }
}
